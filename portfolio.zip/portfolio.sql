-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Sep 12, 2026 at 06:19 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `portfolio`
--

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `certifications`
--

CREATE TABLE `certifications` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `credential_id` varchar(255) DEFAULT NULL,
  `credential_url` varchar(255) DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `certificate_file` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `certifications`
--

INSERT INTO `certifications` (`id`, `name`, `organization`, `credential_id`, `credential_url`, `issue_date`, `expiry_date`, `certificate_file`, `created_at`, `updated_at`) VALUES
(1, 'Business Analysis & Process Management', 'Coursera', 'R7AGDHOVC1OU', 'https://www.coursera.org/account/accomplishments/verify/R7AGDHOVC1OU', '2026-05-01', NULL, NULL, '2026-09-12 13:50:58', '2026-09-12 13:50:58'),
(2, 'Introduction to Project Management with ClickUp', 'Coursera', '29H19GFG3CX5', 'https://www.coursera.org/account/accomplishments/verify/29H19GFG3CX5', '2026-05-01', NULL, NULL, '2026-09-12 13:50:58', '2026-09-12 13:50:58'),
(3, 'Project Management: Creating the WBS', 'Coursera', 'IC23QH3AUU5A', 'https://www.coursera.org/account/accomplishments/verify/IC23QH3AUU5A', '2026-05-01', NULL, NULL, '2026-09-12 13:53:41', '2026-09-12 13:53:41'),
(4, 'The Cybersecurity Threat Landscape', 'LinkedIn', NULL, 'https://www.linkedin.com/learning/certificates/', '2026-01-01', NULL, NULL, '2026-09-12 13:53:41', '2026-09-12 13:53:41');

-- --------------------------------------------------------

--
-- Table structure for table `contact_messages`
--

CREATE TABLE `contact_messages` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `subject` varchar(255) DEFAULT NULL,
  `message` longtext NOT NULL,
  `read` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `educations`
--

CREATE TABLE `educations` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `institution` varchar(255) NOT NULL,
  `qualification` varchar(255) NOT NULL,
  `field_of_study` varchar(255) DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `educations`
--

INSERT INTO `educations` (`id`, `institution`, `qualification`, `field_of_study`, `start_date`, `end_date`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Malawi University of Business and Science (MUBAS)', 'BSc in Information Technology', 'Information Technology', '2019-01-01', '2024-12-31', 'Bachelor of Science in Information Technology.', '2026-09-12 13:11:25', '2026-09-12 13:11:25'),
(2, 'Malawi University of Business and Science (MUBAS)', 'Advanced Diploma in IT Systems Support', 'IT Systems Support', NULL, '2014-12-31', 'Advanced Diploma in IT Systems Support.', '2026-09-12 13:11:25', '2026-09-12 13:11:25'),
(3, 'Malawi University of Business and Science (MUBAS)', 'Diploma in IT Systems Support', 'IT Systems Support', NULL, '2013-12-31', 'Diploma in IT Systems Support.', '2026-09-12 13:11:25', '2026-09-12 13:11:25'),
(4, 'Cisco Networking Academy', 'Cisco IT Essentials Certificate', 'IT Essentials', NULL, '2014-12-31', 'Cisco IT Essentials certification.', '2026-09-12 13:11:25', '2026-09-12 13:11:25');

-- --------------------------------------------------------

--
-- Table structure for table `events`
--

CREATE TABLE `events` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `organization` varchar(255) DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `event_date` date DEFAULT NULL,
  `description` text DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `experiences`
--

CREATE TABLE `experiences` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `job_title` varchar(255) NOT NULL,
  `company` varchar(255) NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `current` tinyint(1) NOT NULL DEFAULT 0,
  `description` longtext DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `experiences`
--

INSERT INTO `experiences` (`id`, `job_title`, `company`, `location`, `start_date`, `end_date`, `current`, `description`, `created_at`, `updated_at`) VALUES
(1, 'ICT Intern', 'YONECO', 'Zomba, Malawi', '2024-11-01', '2025-11-30', 0, 'Completed a one-year ICT internship at YONECO (Youth Net and Counselling), gaining hands-on experience in information and communication technology within a non-governmental organisation setting. Responsibilities included providing technical support to staff, maintaining computer systems and network infrastructure, assisting with database management and data entry, supporting the organisation\'s digital communication platforms, troubleshooting hardware and software issues, and contributing to ICT-related projects that supported youth development and community outreach programmes. Developed practical skills in system administration, network troubleshooting, and the use of technology to support organisational operations and service delivery.', '2026-09-12 13:46:55', '2026-09-12 13:46:55');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

CREATE TABLE `jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) UNSIGNED NOT NULL,
  `reserved_at` int(10) UNSIGNED DEFAULT NULL,
  `available_at` int(10) UNSIGNED NOT NULL,
  `created_at` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2026_09_06_103231_create_profiles_table', 2),
(5, '2026_09_06_103232_create_projects_table', 2),
(6, '2026_09_06_103232_create_skills_table', 2),
(7, '2026_09_06_103233_create_certifications_table', 2),
(8, '2026_09_06_103233_create_education_table', 2),
(9, '2026_09_06_103233_create_experiences_table', 2),
(10, '2026_09_06_103234_create_services_table', 2),
(11, '2026_09_06_103235_create_contact_messages_table', 2),
(12, '2026_09_06_103235_create_events_table', 2),
(13, '2026_09_06_103235_create_social_links_table', 2);

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `profiles`
--

CREATE TABLE `profiles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `subtitle` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `about` longtext DEFAULT NULL,
  `location` varchar(255) DEFAULT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `profile_image` varchar(255) DEFAULT NULL,
  `cv_file` varchar(255) DEFAULT NULL,
  `github_url` varchar(255) DEFAULT NULL,
  `linkedin_url` varchar(255) DEFAULT NULL,
  `facebook_url` varchar(255) DEFAULT NULL,
  `twitter_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profiles`
--

INSERT INTO `profiles` (`id`, `name`, `title`, `subtitle`, `bio`, `about`, `location`, `email`, `phone`, `profile_image`, `cv_file`, `github_url`, `linkedin_url`, `facebook_url`, `twitter_url`, `created_at`, `updated_at`) VALUES
(1, 'Lewis Chikoko', 'IT Specialist & Software Developer', 'BSc in Information Technology', 'Committed to excellence at the highest levels. I am always learning to refine my personal and professional skills to stay relevant on the market.', 'I am an IT professional with a BSc in Information Technology from the Malawi University of Business and Science (MUBAS). I have hands-on experience in computer hardware and software troubleshooting, routing and switching configuration, Windows and Linux server configuration, and software development using frameworks like Laravel. I am passionate about continuous learning and contributing towards organizational goals while advancing my career in the IT industry.', 'Blantyre, Malawi', 'lewischikoko123@gmail.com', '+265 886163309', 'uploads/profile/lewis-chikoko.jpg', 'uploads/cv/lewis-chikoko-cv.pdf', NULL, 'https://www.linkedin.com/in/lewis-chikoko-3a623735b/', NULL, NULL, '2026-09-12 13:22:00', '2026-09-12 13:22:00'),
(2, 'Lewis Chikoko', 'IT Specialist & Software Developer', 'BSc in Information Technology', 'Committed to excellence at the highest levels. I am always learning to refine my personal and professional skills to stay relevant on the market.', 'I am an IT professional with a BSc in Information Technology from the Malawi University of Business and Science (MUBAS). I have hands-on experience in computer hardware and software troubleshooting, routing and switching configuration, Windows and Linux server configuration, and software development using frameworks like Laravel.', 'Blantyre, Malawi', 'lewischikoko123@gmail.com', '+265 886163309', 'resources/files/5D__0679.JPG', NULL, NULL, 'https://www.linkedin.com/in/lewis-chikoko-3a623735b/', NULL, NULL, '2026-09-12 13:25:59', '2026-09-12 13:25:59'),
(3, 'Lewis Chikoko', 'IT Specialist & Software Developer', 'BSc in Information Technology', 'Committed to excellence at the highest levels. I am always learning to refine my personal and professional skills to stay relevant on the market.', 'I am an IT professional with a BSc in Information Technology from the Malawi University of Business and Science (MUBAS). I have hands-on experience in computer hardware and software troubleshooting, routing and switching configuration, Windows and Linux server configuration, and software development using frameworks like Laravel.', 'Blantyre, Malawi', 'lewischikoko123@gmail.com', '+265 886163309', 'files/5D__0679.JPG', NULL, NULL, 'https://www.linkedin.com/in/lewis-chikoko-3a623735b/', NULL, NULL, '2026-09-12 13:29:17', '2026-09-12 13:29:17'),
(4, 'Lewis Chikoko', 'IT Specialist & Software Developer', 'BSc in Information Technology', 'Committed to excellence at the highest levels. I am always learning to refine my personal and professional skills to stay relevant on the market.', 'I am an IT professional with a BSc in Information Technology from the Malawi University of Business and Science (MUBAS). I have hands-on experience in computer hardware and software troubleshooting, routing and switching configuration, Windows and Linux server configuration, and software development using frameworks like Laravel.', 'Blantyre, Malawi', 'lewischikoko123@gmail.com', '+265 886163309', 'public/files/5D__0679.JPG', NULL, NULL, 'https://www.linkedin.com/in/lewis-chikoko-3a623735b/', NULL, NULL, '2026-09-12 13:29:44', '2026-09-12 13:29:44');

-- --------------------------------------------------------

--
-- Table structure for table `projects`
--

CREATE TABLE `projects` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `short_description` text DEFAULT NULL,
  `description` longtext DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL,
  `technologies` varchar(255) DEFAULT NULL,
  `github_url` varchar(255) DEFAULT NULL,
  `live_url` varchar(255) DEFAULT NULL,
  `featured` tinyint(1) NOT NULL DEFAULT 0,
  `status` enum('draft','published') NOT NULL DEFAULT 'published',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `projects`
--

INSERT INTO `projects` (`id`, `title`, `slug`, `short_description`, `description`, `image`, `technologies`, `github_url`, `live_url`, `featured`, `status`, `created_at`, `updated_at`) VALUES
(2, 'IDT4M Digital Advocate — UNDP Malawi', 'idt4m-digital-advocate-undp-malawi', 'Digital transformation advocate supporting Malawi\'s journey toward an inclusive digital future through digital literacy, inclusion, and youth engagement.', 'Passionate digital transformation advocate supporting Malawi\'s journey toward an inclusive digital future. As an IDT4M Digital Advocate, I promote digital literacy, digital inclusion, youth engagement, online safety, and responsible use of technology. I work to raise awareness of digital opportunities, encourage participation in digital innovation, and help bridge the digital divide so that no one is left behind in Malawi\'s digital transformation agenda. Associated with Nzeru Hub.', NULL, 'Digital Literacy, Digital Inclusion, Youth Engagement, Online Safety, Advocacy', NULL, NULL, 1, 'published', '2026-09-12 13:56:35', '2026-09-12 13:56:35'),
(3, 'BEFIT Tablet Asset Verification', 'befit-tablet-asset-verification', 'Data collection and asset verification of BEFIT tablets across Rumphi and Chitipa districts for Imagine Worldwide Malawi.', 'Conducted data collection and asset verification of BEFIT tablets in Rumphi and Chitipa districts, including assessment of device condition, identification of damaged tablets and headphones, and preparation of repair and replacement recommendations submitted to Imagine Worldwide Malawi.', NULL, 'Data Collection, Asset Verification, Field Assessment, Device Inspection, Reporting', NULL, NULL, 0, 'published', '2026-09-12 13:56:35', '2026-09-12 13:56:35');

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `sort_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`id`, `title`, `description`, `icon`, `sort_order`, `status`, `created_at`, `updated_at`) VALUES
(1, 'Network Tutoring', 'One-on-one and group tutoring in computer networking, covering network fundamentals, IP addressing and subnetting, routing and switching, network protocols, troubleshooting methodologies, and practical configuration. Sessions are tailored to each learner\'s level and goals — whether preparing for certification, coursework, or building hands-on industry skills.', '🌐', 1, 1, '2026-09-12 13:58:48', '2026-09-12 13:58:48');

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('eLvC2cXkz9H8ekhSpmC2mByH0pgNJMSt7MfX3LHD', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'YTo1OntzOjY6Il90b2tlbiI7czo0MDoicDNYVVppbEZBSm1odU9jWHd0UXJIYWcxZ2RwSnJPSXNNdE4yRWIxeiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjE6e2k6MDtzOjc6InN1Y2Nlc3MiO319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MzM6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9hZG1pbi9sb2dpbiI7czo1OiJyb3V0ZSI7czoxMToiYWRtaW4ubG9naW4iO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO3M6Nzoic3VjY2VzcyI7czoxMzoiV2VsY29tZSBiYWNrISI7fQ==', 1789220501),
('QOpPfAlWuAcEjTgSEcuaq6Iz4UFwM7FfbgBLHLVd', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36 Edg/153.0.0.0', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiVk9JYVNxMDFHZXdxamNDWUx3VkRyYTh3d3BnblNRUDVRVXREMzBISSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6Mjp7czozOiJ1cmwiO3M6MjE6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMCI7czo1OiJyb3V0ZSI7czo0OiJob21lIjt9fQ==', 1789228452);

-- --------------------------------------------------------

--
-- Table structure for table `skills`
--

CREATE TABLE `skills` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `percentage` tinyint(3) UNSIGNED NOT NULL DEFAULT 0,
  `icon` varchar(255) DEFAULT NULL,
  `sort_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `skills`
--

INSERT INTO `skills` (`id`, `name`, `category`, `percentage`, `icon`, `sort_order`, `status`, `created_at`, `updated_at`) VALUES
(15, 'Internet of Things', 'Internet of Things', 85, 'fa-iot', 15, 1, '2026-09-12 13:12:37', '2026-09-12 13:12:37'),
(24, 'Computer Hardware & Software Troubleshooting', 'Hardware & Software', 90, 'fa-tools', 1, 1, '2026-09-12 13:13:23', '2026-09-12 13:13:23'),
(25, 'Routing & Switching Configuration', 'Networking', 88, 'fa-network-wired', 2, 1, '2026-09-12 13:13:23', '2026-09-12 13:13:23'),
(26, 'Windows & Linux Server Configuration', 'Servers & Systems', 85, 'fa-server', 3, 1, '2026-09-12 13:13:23', '2026-09-12 13:13:23'),
(27, 'Laravel Framework Development', 'Software Development', 85, 'fa-laravel', 4, 1, '2026-09-12 13:13:23', '2026-09-12 13:13:23'),
(28, 'MySQL Database Management', 'Databases', 85, 'fa-database', 5, 1, '2026-09-12 13:13:23', '2026-09-12 13:13:23');

-- --------------------------------------------------------

--
-- Table structure for table `social_links`
--

CREATE TABLE `social_links` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `platform` varchar(255) NOT NULL,
  `url` varchar(255) NOT NULL,
  `icon` varchar(255) DEFAULT NULL,
  `sort_order` int(10) UNSIGNED NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `created_at`, `updated_at`) VALUES
(1, 'Portfolio Administrator', 'admin@portfolio.test', NULL, '$2y$12$8oQ0cpEqvlfl5D/gtLKmVeTYKQrih82jFdYQ9ZvPPoo5ArnZwPjvq', NULL, '2026-09-06 09:01:32', '2026-09-06 09:01:32');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cache`
--
ALTER TABLE `cache`
  ADD PRIMARY KEY (`key`),
  ADD KEY `cache_expiration_index` (`expiration`);

--
-- Indexes for table `cache_locks`
--
ALTER TABLE `cache_locks`
  ADD PRIMARY KEY (`key`),
  ADD KEY `cache_locks_expiration_index` (`expiration`);

--
-- Indexes for table `certifications`
--
ALTER TABLE `certifications`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `contact_messages`
--
ALTER TABLE `contact_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `educations`
--
ALTER TABLE `educations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `events`
--
ALTER TABLE `events`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `experiences`
--
ALTER TABLE `experiences`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

--
-- Indexes for table `jobs`
--
ALTER TABLE `jobs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `jobs_queue_index` (`queue`);

--
-- Indexes for table `job_batches`
--
ALTER TABLE `job_batches`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `password_reset_tokens`
--
ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`email`);

--
-- Indexes for table `profiles`
--
ALTER TABLE `profiles`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `projects`
--
ALTER TABLE `projects`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `projects_slug_unique` (`slug`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indexes for table `skills`
--
ALTER TABLE `skills`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `social_links`
--
ALTER TABLE `social_links`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_email_unique` (`email`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `certifications`
--
ALTER TABLE `certifications`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contact_messages`
--
ALTER TABLE `contact_messages`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `educations`
--
ALTER TABLE `educations`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `events`
--
ALTER TABLE `events`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `experiences`
--
ALTER TABLE `experiences`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `failed_jobs`
--
ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `jobs`
--
ALTER TABLE `jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `migrations`
--
ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `profiles`
--
ALTER TABLE `profiles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `projects`
--
ALTER TABLE `projects`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `skills`
--
ALTER TABLE `skills`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

--
-- AUTO_INCREMENT for table `social_links`
--
ALTER TABLE `social_links`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
